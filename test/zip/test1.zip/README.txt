This file is a sample zip file used by Caprice32 tests.
